from Funciones.Vista import Vista
class Main():
    vista = Vista()
    vista.pintarTeclado()
